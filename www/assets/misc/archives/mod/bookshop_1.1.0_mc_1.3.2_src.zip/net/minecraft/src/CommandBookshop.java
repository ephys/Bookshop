package net.minecraft.src;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;

// todo:
// - language managed in a config file
// - giveBook managed in a config file

public class CommandBookshop extends CommandBase
{
	public boolean giveBook = false;
	static private String API_URL = "http://aperturelaboratories.eu/bookshop/api/";
	private String commandSyntax = "/bookshop download|dl <id>\n/bookshop upload|up <token>\n/bookshop list [author]";
	
    public String getCommandName()
    {
        return "bookshop";
    }

    public String getCommandUsage(ICommandSender par1ICommandSender)
    {
        return commandSyntax;
    }

    public void processCommand(ICommandSender par1ICommandSender, String[] par2ArrayOfStr)
    {
    	EntityPlayer player = getCommandSenderAsPlayer(par1ICommandSender);
    	ItemStack inHand = player.getCurrentEquippedItem();
    	if(par2ArrayOfStr.length < 1) {
    		par1ICommandSender.sendChatToPlayer(commandSyntax);
    		return;
    	}
    	
    	// traitement de la commande "dl" || "download"
    	if(par2ArrayOfStr[0].equalsIgnoreCase("dl") || par2ArrayOfStr[0].equalsIgnoreCase("download")) {
    		if(par2ArrayOfStr.length != 2) {
    			par1ICommandSender.sendChatToPlayer("Syntax : /bookshop dl <id>");
    			return;
    		}
    		
    		player.sendChatToPlayer("Loading...");
    		if(!this.giveBook) {
    			if(inHand == null) {
    				player.sendChatToPlayer("You must have a book in hand.");
	    			return;
    			} else if(inHand.itemID != Item.book.shiftedIndex && inHand.itemID != Item.writableBook.shiftedIndex && inHand.itemID != Item.writtenBook.shiftedIndex) {
	    			player.sendChatToPlayer("You must have a book in hand.");
	    			return;
    			}
    		}
    		
    		JSONObject book_json = loadBook(par2ArrayOfStr[1]);
    		if(book_json == null) {
    			player.sendChatToPlayer("Failled parsing JSON");
    			return;
    		} else {
    			if (book_json.isNull("error"))
    	    		try {
    	    			List bookPages = new ArrayList();
    	    			String bookAuthor = book_json.getString("author");
    	    			String bookTitle = book_json.getString("title");
    	    			JSONArray ps = book_json.getJSONArray("pages");
    	    			
    	    			if(ps.length() == 0) {
    	    				player.sendChatToPlayer("Empty Book");
    	    			} else {
    		    			for (int i = 0; i < ps.length(); i++)
    		    			{
    							bookPages.add(ps.getString(i));
    		    			}
    		    			
    		    			if(!this.giveBook)
    		    				createBook(bookTitle, bookPages, bookAuthor, player, inHand);
    		    			else
    		    				createBook(bookTitle, bookPages, bookAuthor, player);
    	    			}
    	    		}
    	    		catch (JSONException e) { }
    	    	else {
    	    		try {
    	    			player.sendChatToPlayer(book_json.getString("error"));
    	    		}
    	    		catch (JSONException e) { }
    	    		return;
    	    	}	
    		}
    	}
    	// traitement de la commande "up" || "upload"
    	else if(par2ArrayOfStr[0].equalsIgnoreCase("up") || par2ArrayOfStr[0].equalsIgnoreCase("upload")) {
    		if(inHand == null) {
				player.sendChatToPlayer("You must have a book in hand.");
    			return;
			} else if(inHand.itemID != Item.book.shiftedIndex && inHand.itemID != Item.writableBook.shiftedIndex && inHand.itemID != Item.writtenBook.shiftedIndex) {
    			player.sendChatToPlayer("You must have a book in hand.");
    			return;
			}
    		
    		if(par2ArrayOfStr.length != 2) {
    			par1ICommandSender.sendChatToPlayer("Syntax : /bookshop up <token>");
    			return;
    		}
    		
    		uploadBook(player, inHand, par2ArrayOfStr[1]);
    	} else if(par2ArrayOfStr[0].equalsIgnoreCase("list")) {
    		if(par2ArrayOfStr.length != 2)
    			loadUserBooks(player, player.username);
    		else
    			loadUserBooks(player, par2ArrayOfStr[1]);
    	} else {
    		par1ICommandSender.sendChatToPlayer(commandSyntax);
    	}
    }
    
    public JSONObject loadBook(final String id) {
    	String request_url = API_URL+"download.php?id="+id;

    	try
        {
    		InputStream is = new URL(request_url).openStream();

    		BufferedReader br = new BufferedReader(new InputStreamReader(is));

    		String l = br.readLine();

    		return new JSONObject(l);
        }
		catch (Exception e)
		{
			e.printStackTrace();
		}
    	
    	return null;
    }
    
    // version on modifie le contenu du livre
    private void createBook(final String title, final List pagesArray, final String author, final EntityPlayer player, final ItemStack inHand) {
    	new Thread() {
	      public void run() {
	    	  Minecraft mc = Minecraft.getMinecraft();
	    	  String s = "MC|BEdit";
	    	  if(inHand.itemID == Item.book.shiftedIndex) {
	    		  inHand.itemID = Item.writtenBook.shiftedIndex;
	    	  } else if(inHand.itemID != Item.writableBook.shiftedIndex && inHand.itemID != Item.writtenBook.shiftedIndex) {
	    		  player.sendChatToPlayer("You must have a book in hand.");
	    		  return;
	    	  }
	    	  
	    	  NBTTagCompound nbttagcompound = inHand.getTagCompound();
	        
	    	  NBTTagList pages_tag = new NBTTagList("pages");
	    	  for (int i = 0; i < pagesArray.size(); i++) {
	    		  pages_tag.appendTag(new NBTTagString(i + 1 + "", ((String)pagesArray.get(i)).replaceAll("\r", "")));
	    	  }

	    	  inHand.func_77983_a("pages", pages_tag);
	    	  if(inHand.itemID == Item.writtenBook.shiftedIndex) {
	    		  s = "MC|BSign";
	    		  inHand.func_77983_a("author", new NBTTagString("author", author.trim()));
	    		  inHand.func_77983_a("title", new NBTTagString("title", title.trim()));
	    	  }
	    	  
	    	  player.sendChatToPlayer("Loaded");

	    	  ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
	    	  DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);
	    	  try
	    	  {
	    		  Packet.writeItemStack(inHand, dataoutputstream);
	    		  mc.getSendQueue().addToSendQueue(new Packet250CustomPayload(s, bytearrayoutputstream.toByteArray()));
	    	  }
	    	  catch (Exception exception)
	    	  {
	    		  exception.printStackTrace();
	    	  }
	      }
	    }
	    .start();
    }
    
    // version on /give le book
    private void createBook(final String title, final List pagesArray, final String author, final EntityPlayer player) {
    	new Thread() {
	      public void run() {
	        String s = "MC|BSign";
	        Minecraft mc = Minecraft.getMinecraft();
	        ItemStack itemstackBook = new ItemStack(Item.writtenBook, 1);
	        NBTTagCompound nbttagcompound = itemstackBook.getTagCompound();
	        
	        NBTTagList pages_tag = new NBTTagList("pages");
	        for (int i = 0; i < pagesArray.size(); i++) {
	          pages_tag.appendTag(new NBTTagString(i + 1 + "", (String)pagesArray.get(i)));
	        }

	        itemstackBook.func_77983_a("author", new NBTTagString("author", author.trim()));
	        itemstackBook.func_77983_a("title", new NBTTagString("title", title.trim()));
	        itemstackBook.func_77983_a("pages", pages_tag);
	        player.dropPlayerItem(itemstackBook);

	        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
	        DataOutputStream dataoutputstream = new DataOutputStream(bytearrayoutputstream);
	        try
	        {
                Packet.writeItemStack(itemstackBook, dataoutputstream);
                mc.getSendQueue().addToSendQueue(new Packet250CustomPayload(s, bytearrayoutputstream.toByteArray()));
	        }
	        catch (Exception exception)
	        {
	        	exception.printStackTrace();
	        }
	      }
	    }
	    .start();
    }
    
    private void uploadBook(final EntityPlayer player, final ItemStack book, final String token) {
	    new Thread()
	    {
	      public void run() {
	        NBTTagCompound nbttagcompound = book.getTagCompound();
	        NBTTagList tag_pages = nbttagcompound.getTagList("pages");
	        int page_number = 0;
	        if (tag_pages != null) {
	          tag_pages = (NBTTagList)tag_pages.copy();
	          page_number = tag_pages.tagCount();
	
	          if (page_number < 1) {
	        	  page_number = 0;
	          }
	        }
	
	        ArrayList list = new ArrayList();
	        for (int i = 0; i < tag_pages.tagCount(); i++) {
	        	NBTTagString page = (NBTTagString)tag_pages.tagAt(i);
	        	list.add(page.toString());
	        }
	
	        try {
	          JSONObject jso = new JSONObject();
	          jso.put("pages", list);
	          if(book.itemID == Item.writtenBook.shiftedIndex) {
	        	  jso.put("title", nbttagcompound.getString("title"));
	        	  jso.put("author", nbttagcompound.getString("author"));
	          } else if(book.itemID == Item.writableBook.shiftedIndex) {
	        	  jso.put("title", "");
	        	  jso.put("author", player.username);
	          } else {
	        	  return;
	          }
	
	          String jsonEncodedBook = jso.toString();
	          jsonEncodedBook = URLEncoder.encode(jsonEncodedBook, "UTF-8");
	
	          String url = API_URL+"upload.php?username=" + player.username + "&token=" + token + "&data=" + jsonEncodedBook;
	          
	          InputStream is = new URL(url).openStream();
	
	          BufferedReader br = new BufferedReader(new InputStreamReader(is));
	
	          String retour = br.readLine();
	
	          JSONObject json_data = new JSONObject(retour);
	          String messageR;
	          if (json_data.isNull("error"))
	            messageR = json_data.getString("success");
	          else {
	            messageR = json_data.getString("error");
	          }
	          player.sendChatToPlayer(messageR);
	        }
	        catch (JSONException e) {
	          e.printStackTrace();
	        } catch (IOException e) {
	          e.printStackTrace();
	        }
	      }
	    }
	    .start();
	}
    
    private void loadUserBooks(EntityPlayer player, String username) {
        String url = API_URL+"members.php?username=" + username;
        InputStream is;
		try {
			is = new URL(url).openStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        JSONObject json_data;
			try {
				json_data = new JSONObject(br.readLine());
				if(json_data.isNull("error")) {
					Iterator<String> myIter = json_data.keys();
					List<String> keys = new ArrayList<String>();

				    while(myIter.hasNext()){
				    	keys.add(myIter.next());
				    }
				    
				    if(keys.isEmpty())
				    	player.sendChatToPlayer(username+" has no books");
				    else {
				    	player.sendChatToPlayer(username+"'s booklist: ");
					    Collections.sort(keys);
					    for(String key : keys){
					    	player.sendChatToPlayer("- "+json_data.getString(key) + " (" + key + ")");
					    }	
				    }
				} else {
					player.sendChatToPlayer(json_data.getString("error"));
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
