package nf.fr.bookshop;
// http://puu.sh/1jP63
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.Mod.PostInit;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.Mod.ServerStarting;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.network.NetworkMod;

import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandManager;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.ServerCommandManager;
import net.minecraft.src.ModLoader;
import net.minecraftforge.common.ForgeHooks;

@Mod(modid = "ephys.bookshop", name = "Bookshop", version = "1.5.0")
@NetworkMod(clientSideRequired = false, serverSideRequired = false)
public class Bookshop {
    public static LinkedProperties props;
    private static String propsLocation;
    public static LinkedProperties lang;
    private static String langLocation;
    public static String API_URL = "http://api.bookshop.fr.nf/";

	@Instance("ephys.bookshop")
	public static Bookshop instance;
	
	@PreInit
	public void preInit(FMLPreInitializationEvent event) {}

	@Init
	public void init(FMLInitializationEvent event) {
		propsLocation = new StringBuilder().append(Minecraft.getMinecraftDir()).append("/mods/mod_bookshop.props").toString();
		try {
			props = loadProperties(propsLocation);
		} catch (Exception e) {
			//e.printStackTrace();
			try {
				createPropsFile(propsLocation);
				props = loadProperties(propsLocation);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		langLocation = new StringBuilder().append(Minecraft.getMinecraftDir()).append("/mods/mod_bookshop.lang").toString();
		try {
			lang = loadProperties(langLocation);
		} catch (Exception e) {
			//e.printStackTrace();
			try {
				createLangFile(langLocation);
				lang = loadProperties(langLocation);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	@ServerStarting
	public void serverStarting(FMLServerStartingEvent event)
	{
		ServerCommandManager serverCommandManager = ((ServerCommandManager) ModLoader.getMinecraftServerInstance().getCommandManager()); 
		serverCommandManager.registerCommand(new CommandBookshop());
	}

	@PostInit
	public static void postInit(FMLPostInitializationEvent event) {}
	
	public LinkedProperties loadProperties(String location) throws FileNotFoundException, IOException 
	{
		LinkedProperties props = new LinkedProperties();
		props.load(new FileInputStream(location));
		return props;
	}
	
	public static void saveProperties(LinkedProperties props, String fileLocation, String comments) throws IOException 
	{
		try {
			OutputStream out = new FileOutputStream(fileLocation);
			props.store(out, comments);
			out.flush();
			out.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void createPropsFile(String location) throws IOException
	{
		props = new LinkedProperties();
		
		props.setProperty("download.giveBook", "false");
		props.setProperty("MCWiki.API.URL", "http://www.minecraftwiki.net/api.php");
		props.setProperty("bookshop.login", "");
		props.setProperty("bookshop.password", "");

		saveProperties(props, location, null);
	}
	
	public static void setProp(String key, String prop) throws IOException {
		props.setProperty(key, prop);
		saveProperties(props, propsLocation, null);
	}
	
	public void createLangFile(String location) throws IOException
	{
		lang = new LinkedProperties();
		
		lang.setProperty("language.syntax", "Syntax");
		lang.setProperty("language.info", "For more informations, visit");
		lang.setProperty("language.loading", "Loading...");
		lang.setProperty("language.loaded", "Loaded.");
		lang.setProperty("language.uploadComplete", "Saved with id");
		lang.setProperty("language.error.noBook", "You must have a book in hand.");
		lang.setProperty("language.error.notFound", "No such book registered.");
		lang.setProperty("language.error.empty", "Empty book.");
		lang.setProperty("language.error.bookListEmpty", "No (public) books in our database.");
		lang.setProperty("language.error.titleListEmpty", "No Match.");
		lang.setProperty("language.error.request", "Request Faillure.");
		lang.setProperty("language.bookList", "Book List:");
		lang.setProperty("language.titleList", "Titles matching");

		saveProperties(lang, langLocation, null);
	}
	
	public static Boolean getBooleanProp(String prop)
	{
		return Boolean.parseBoolean((String)props.get(prop));
	}
	
	public static String getStringProp(String prop)
	{
		return (String)props.get(prop);
	}
	
	public static String getTranslation(String sentence) {
		return (String)lang.getProperty(sentence);
	}
	
	public static Integer getIntegerProp(String prop) {
		return Integer.parseInt((String)props.get(prop));
	}
}