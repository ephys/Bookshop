package net.minecraft.src;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import net.minecraft.client.Minecraft;

public class mod_bookshop extends BaseMod {

    public String Version()
    {
        return "Bookshop";
    }
   
    public mod_bookshop()
    {
        ModLoader.addCommand(new CommandBookshop());
    }

    @Override
    public String getVersion() {
        return "1.2.1";
    }

    @Override
    public void load() {
        // TODO Auto-generated method stub
    }
}