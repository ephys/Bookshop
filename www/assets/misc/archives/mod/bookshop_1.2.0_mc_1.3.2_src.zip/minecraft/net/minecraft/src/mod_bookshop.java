package net.minecraft.src;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import net.minecraft.client.Minecraft;

public class mod_bookshop extends BaseMod {

    public String Version()
    {
        return "Bookshop 1.2";
    }
   
    public mod_bookshop()
    {
        ModLoader.addCommand(new CommandBookshop());
    }

    @Override
    public String getVersion() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void load() {
        // TODO Auto-generated method stub
    }
}