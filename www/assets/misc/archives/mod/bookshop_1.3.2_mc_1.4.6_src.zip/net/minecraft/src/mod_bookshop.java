package net.minecraft.src;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import net.minecraft.client.Minecraft;

public class mod_bookshop extends BaseMod {
    public static LinkedProperties props;
    private static String propsLocation;
    public static LinkedProperties lang;
    private static String langLocation;
    public static String API_URL = "http://api.bookshop.fr.nf/";
    
    public mod_bookshop() {
    }

    @Override
    public String getVersion() {
        return "1.2.1";
    }
	
    public String Version() {
        return "Bookshop";
    }
    // http://puu.sh/1jP63
  
	public void load() {
		propsLocation = new StringBuilder().append(Minecraft.getMinecraftDir()).append("/mods/mod_bookshop.props").toString();
		try {
			props = loadProperties(propsLocation);
		} catch (Exception e) {
			//e.printStackTrace();
			try {
				createPropsFile(propsLocation);
				props = loadProperties(propsLocation);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		langLocation = new StringBuilder().append(Minecraft.getMinecraftDir()).append("/mods/mod_bookshop.lang").toString();
		try {
			lang = loadProperties(langLocation);
		} catch (Exception e) {
			//e.printStackTrace();
			try {
				createLangFile(langLocation);
				lang = loadProperties(langLocation);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		ModLoader.addCommand(new CommandBookshop(this));
	}
	
	public LinkedProperties loadProperties(String location) throws FileNotFoundException, IOException 
	{
		LinkedProperties props = new LinkedProperties();
		props.load(new FileInputStream(location));
		return props;
	}
	
	public void saveProperties(LinkedProperties props, String fileLocation, String comments) throws IOException 
	{
		try {
			OutputStream out = new FileOutputStream(fileLocation);
			props.store(out, comments);
			out.flush();
			out.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void createPropsFile(String location) throws IOException
	{
		props = new LinkedProperties();
		
		props.setProperty("download.giveBook", "false");
		props.setProperty("MCWiki.API.URL", "http://www.minecraftwiki.net/api.php");
		props.setProperty("bookshop.login", "");
		props.setProperty("bookshop.password", "");

		saveProperties(props, location, null);
	}
	
	public void setProp(String key, String prop) throws IOException {
		this.props.setProperty(key, prop);
		saveProperties(this.props, this.propsLocation, null);
	}
	
	public void createLangFile(String location) throws IOException
	{
		lang = new LinkedProperties();
		
		lang.setProperty("language.syntax", "Syntax");
		lang.setProperty("language.info", "For more informations, visit");
		lang.setProperty("language.loading", "Loading...");
		lang.setProperty("language.loaded", "Loaded.");
		lang.setProperty("language.uploadComplete", "Saved with id");
		lang.setProperty("language.error.noBook", "You must have a book in hand.");
		lang.setProperty("language.error.notFound", "No such book registered.");
		lang.setProperty("language.error.empty", "Empty book.");
		lang.setProperty("language.error.bookListEmpty", "No (public) books in our database.");
		lang.setProperty("language.error.titleListEmpty", "No Match.");
		lang.setProperty("language.error.request", "Request Faillure.");
		lang.setProperty("language.bookList", "Book List:");
		lang.setProperty("language.titleList", "Titles matching");

		saveProperties(lang, langLocation, null);
	}
	
	public static Boolean getBooleanProp(String prop)
	{
		return Boolean.parseBoolean((String)props.get(prop));
	}
	
	public static String getStringProp(String prop)
	{
		return (String)props.get(prop);
	}
	
	public static String getTranslation(String sentence) {
		return (String)lang.getProperty(sentence);
	}
	
	public static Integer getIntegerProp(String prop) {
		return Integer.parseInt((String)props.get(prop));
	}
}